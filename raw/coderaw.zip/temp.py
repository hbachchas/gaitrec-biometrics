

import numpy as np
from numpy.core.fromnumeric import shape
from scipy import signal
from matplotlib import pyplot as plt



x = np.reshape(np.arange(5*3), (5,3))
x[1,0] = np.array([0])
x[3,1:] = np.array([0,0])

rd = np.array([1,2,3,4,5,6,12,17,23,31,45,49,58,75,79,85])
freqs, psd = signal.welch(rd,return_onesided=True)

plt.figure(figsize=(5, 4))
plt.semilogx(freqs, psd)
plt.title('PSD: power spectral density')
plt.xlabel('Frequency')
plt.ylabel('Power')
plt.tight_layout()
plt.show()


x = np.array([1,2,3,4,5])
y = np.array([1,2,3,4,5])

z = x*y

x = np.array([
	[1,2],
	[3,4],
	[5,6],
	[7,8],
])


from scipy.spatial import distance
d = distance.cdist(x,x,metric='euclidean')
bestpair = np.unravel_index(d.argmax(), d.shape)


pass









#########-----------------------------  Dataset code ---------------------------------##########

# a = np.array([
# 	[12,28,0,19],
# 	[15,29,1,8],
# 	[17,21,0,10],
# 	[13,25,1,14],
# 	[14,20,0,11],
# 	[13,27,0,18],
# ])

# x = a[:,2] == 1
# y = a[x]
# z1 = a[np.invert(x)]
# z2 = a[a[:,2] == 0]
# print(z1-z2)



# Read metadata npy file
# md_bfoot = np.load('/home/peace/Documents/rtx2080_personal_main_system_bkp_noida_april_15_2021/NEW_since april 15 2021/postdoc related/atests/UNB/data/perFootDataBarefoot/PerFootMetaDataBarefoot.npy')
# md_abfoot = np.load('/home/peace/Documents/rtx2080_personal_main_system_bkp_noida_april_15_2021/NEW_since april 15 2021/postdoc related/atests/UNB/data/alignedPerFootDataBarefoot/AlignedFootMetaDataBarefoot.npy')

# md_bfoot_c = md_bfoot[md_bfoot[:,3] == 0]		# find complete steps
# md_abfoot_c = md_abfoot[md_bfoot[:,3] == 0]		# find complete steps

# md_bfoot_data = np.load('/home/peace/Documents/rtx2080_personal_main_system_bkp_noida_april_15_2021/NEW_since april 15 2021/postdoc related/atests/UNB/data/alignedPerFootDataBarefoot/AlignedFootDataBarefoot.npz')
# md_abfoot_data = np.load('/home/peace/Documents/rtx2080_personal_main_system_bkp_noida_april_15_2021/NEW_since april 15 2021/postdoc related/atests/UNB/data/perFootDataBarefoot/PerFootDataBarefoot.npz')



# # Read npz data file
# lst = md_abfoot_data.files

# for item in lst:
# 	y = item
# 	yy = md_abfoot_data[item]
# 	break
