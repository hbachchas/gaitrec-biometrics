""" For visualizations """


import numpy as np
import matplotlib.pyplot as plt


#






def vis_mat(mat):
	plt.matshow(mat);
	plt.colorbar()
	plt.show()





a = np.array([
	[0,0,0,0],
	[0,1,1,0],
	[1,1,1,1],
	[0,1,1,0],
	[0,1,0,0],
	[0,1,1,0],
])
# vis_mat(a)

b = np.array((
	[0,1,1,0],
	[0,1,0,0],
	[0,0,0,0],
	[0,0,1,1],
	[0,0,1,1]))
# vis_mat(b)

c = np.array([
	[0.1,0,0,0],
	[0,11,1,0],
	[1,1,1,1],
	[0,1,1,2.3],
	[0,1,0,0],
	[0,1,1,0],
])

pass